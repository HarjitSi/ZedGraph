This is the interactive demo project for ZedGraph, which just shows a bunch of sample graphs demonstrating various features. 
Complete source code for the demo is included with this distribution.  For easy distribution, this archive provides only the
.Net 2.0 dll form of ZedGraph.  However, complete source codes for both .Net 2.0 and .Net 1.1 of ZedGraph are available.

Version 4.6.x is the .Net 1.1 compatible version
Version 5.1.x is the .Net 2.0 compatible version

Complete source code for ZedGraph is available on sourceforge here:

    http://sourceforge.net/projects/zedgraph/

A wiki providing help, samples, etc. is available here:

    http://zedgraph.org
    
A tutorial on using ZedGraph is available here:

http://www.codeproject.com/csharp/zedgraph.asp



